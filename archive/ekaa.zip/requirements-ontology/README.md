# Requirements Ontology

The requirements ontology combines the approach of Goal-Oriented Requirements Engineering (GORE) and Feature-oriented Requirements Engineering to offer concepts for describing hierarchy of requirements, their relation to goals (as state-context specification), and the means of achieving the goals (via components, sub-systems, and systems).

## Overview
The story is actually simple (it should be so): requirement in building automation (BA) is a narrative which principally contains **what** is to happen **where** (i.e. the context), and sometimes includes **how** it should be done (i.e. system specification). The **how** part can include the physical system and its component and/or the automation function.

Lets take some examples:

**The temperature of office rooms shall be maintained within +/- 1 deg-C of the setpoint using a combination of radiator and VAV**

Evidently, such narratives are often incomplete or inconsistent. However, the implementation of the automation system has to fulfill the requirements, while operating in an environment whose system design is often given (and hence, carries over the incompleteness and inconsistencies).

The idea behind this **knowledge-driven** requirements engineering is that such incompleteness and inconsistencies can be detected early in the engineering. An added benefit is that it can potentially **automate** parts of the automation engineering too. The following diagram gives a very fluffy overview of the concepts that will envetually come together (in case you are wondering, the BTDom ontologies will be handy in describing the green and blue stuff. The requirements (yellow) is what this ontology attempts to patch in. The challenge of describing the physical processes (purple) is not that easy and I havent really given it much thought. But it will come soon.

![Overview of the fluffy stuff](/images/overview.png "This ontology is about the yellow stuff")

## The Essentials
The ontology is easier viewed with requirements at the center. The **Requirement** principally seeks to describe **what** needs to to happen **where**. The **what** part involves describing the goal, and in some cases, **how** it should be achieved. Either the **Requirement** or the subsequent design process describes the **means** by which the goal is achieved. In all cases, the principal aim is to define the goal as the state of the physical process that needs to be established in the context. The following diagram explains this visually (the relationships and classes are loosely name):

![Overview of the relations](/images/relations.png "Requirement seeks to tell where, what, and how story")

To illustrate this further, let us look at an example:

![An example](/images/relations_example.png "The need to keep the room warm")

## Understanding the Ontology
I am skipping the formal description (which tell the same story as above but in a painful manner).


## How to use the example
The example is based on the Winehouse building (which is the smallest thermodynamically operational building in the world and is inhabited by Lego figures. See [here](https://code.siemens.com/prd-wot/winehouse)).
You can load the example and  the ontology ttl is any graph database (I like GraphDB) and run some interesting queries:

Give me all requirements, its associated contexts, the equipment used, and the control strategies:

```
PREFIX btrq: <http://bt.schema.siemens.io/custom/btrq#>
select * where { 
	?req a btrq:Requirement .
    ?req btrq:hasContext ?c.
    ?req btrq:achievedBy ?equipment.
    ?equipment a btrq:SystemDesignEntity.
    ?req btrq:achievedBy ?automation.
    ?automation a btrq:AutomationStrategy.
}
```